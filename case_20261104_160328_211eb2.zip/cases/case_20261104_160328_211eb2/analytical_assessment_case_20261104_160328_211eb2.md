# Internal Analytical Assessment

**Readiness:** `PARTIALLY READY`

## Executive Summary
The internal assessment is based on the finalized requirements, rulebook evidence, workspace metadata mapping, and human validation results. Unverified conclusions remain explicitly unverified.

## Requirement Inventory
- REQ-001: Consolidate Zoho Books financial data and external Excel cash records into a unified P&L statement in Zoho Analytics.
- REQ-002: Deliver a property-level Custom P&L with the defined financial, occupancy, and cash-flow measures for a selected property and period.
- REQ-003: Deliver a portfolio and all-properties comparison with property, revenue, profit, EBITDA, and net cash-flow measures.
- REQ-004: Deliver a current-assets summary for security deposits, brokerage, and setup/photoshoot costs, separate from operating P&L.
- REQ-005: Build and demonstrate a feasibility sample, then produce a statement of work containing the finalized scope, timeline, and cost estimates.
- None identified.

## Confirmed Objectives
- Replace fragmented financial reporting with one reconciled P&L view.
- Use feasibility evidence to make the implementation decision.
- None identified.

## Transcript Reconciliation
- The requested outcome is a unified P&L from Zoho Books and external Excel cash data.
- The client wants a feasibility assessment, quotation, and implementation scope.
- The client requested a reference to the previously attempted dashboard before proceeding.
- None identified.

## Unresolved Assumptions
- None identified.

## Contradictions
- None identified.

## Technical Limitations
- Metadata-only discovery cannot establish record completeness, value accuracy, or historical coverage.
- None identified.

## Implementation Considerations
- None identified.

## Quality Checks
- Formal requirements were compared with the finalized decomposition.
- Workspace claims are limited to supplied metadata and human validation.
- Unknowns remain UNVERIFIED rather than being promoted to confirmed facts.
- None identified.

## Metric and Feasibility Analysis
- No metric analysis was returned.

## Metadata Mappings
- REQ-001: [MOCK] best-effort keyword match for concept: [field] property_id -> Books_Bills.property_id (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in Books_Bills: property_id.
- REQ-001: [MOCK] best-effort keyword match for concept: [field] reporting period -> Books_Accounts.Books_Accounts (`POTENTIAL MATCH`; UNVERIFIED) - Candidate table Books_Accounts selected but no exact field match was found.
- REQ-001: [MOCK] best-effort keyword match for concept: [field] account_name -> Books_Accounts.account_name (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in Books_Accounts: account_name.
- REQ-001: [MOCK] best-effort keyword match for concept: [aggregation] amount -> Books_Cash_Transactions.amount (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in Books_Cash_Transactions: amount.
- REQ-002: [MOCK] best-effort keyword match for concept: [field] property_id -> Books_Bills.property_id (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in Books_Bills: property_id.
- REQ-002: [MOCK] best-effort keyword match for concept: [field] reporting period -> Books_Accounts.Books_Accounts (`POTENTIAL MATCH`; UNVERIFIED) - Candidate table Books_Accounts selected but no exact field match was found.
- REQ-002: [MOCK] best-effort keyword match for concept: [field] account_name -> Books_Accounts.account_name (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in Books_Accounts: account_name.
- REQ-002: [MOCK] best-effort keyword match for concept: [aggregation] amount -> Books_Cash_Transactions.amount (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in Books_Cash_Transactions: amount.
- REQ-002: [MOCK] best-effort keyword match for concept: [field] nights_considered -> PMS_Monthly_Performance.nights_considered (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in PMS_Monthly_Performance: nights_considered.
- REQ-002: [MOCK] best-effort keyword match for concept: [field] nights_booked -> PMS_Monthly_Performance.nights_booked (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in PMS_Monthly_Performance: nights_booked.
- REQ-002: [MOCK] best-effort keyword match for concept: [aggregation] occupancy percentage = nights booked / nights considered -> Books_Accounts.Books_Accounts (`POTENTIAL MATCH`; UNVERIFIED) - Candidate table Books_Accounts selected but no exact field match was found.
- REQ-002: [MOCK] best-effort keyword match for concept: [aggregation] revenue by reporting period -> Books_Accounts.Books_Accounts (`POTENTIAL MATCH`; UNVERIFIED) - Candidate table Books_Accounts selected but no exact field match was found.
- REQ-003: [MOCK] best-effort keyword match for concept: [field] property_id -> Books_Bills.property_id (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in Books_Bills: property_id.
- REQ-003: [MOCK] best-effort keyword match for concept: [field] reporting period -> Books_Accounts.Books_Accounts (`POTENTIAL MATCH`; UNVERIFIED) - Candidate table Books_Accounts selected but no exact field match was found.
- REQ-003: [MOCK] best-effort keyword match for concept: [field] account_name -> Books_Accounts.account_name (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in Books_Accounts: account_name.
- REQ-003: [MOCK] best-effort keyword match for concept: [aggregation] amount -> Books_Cash_Transactions.amount (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in Books_Cash_Transactions: amount.
- REQ-003: [MOCK] best-effort keyword match for concept: [field] nights_considered -> PMS_Monthly_Performance.nights_considered (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in PMS_Monthly_Performance: nights_considered.
- REQ-003: [MOCK] best-effort keyword match for concept: [field] nights_booked -> PMS_Monthly_Performance.nights_booked (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in PMS_Monthly_Performance: nights_booked.
- REQ-003: [MOCK] best-effort keyword match for concept: [aggregation] occupancy percentage = nights booked / nights considered -> Books_Accounts.Books_Accounts (`POTENTIAL MATCH`; UNVERIFIED) - Candidate table Books_Accounts selected but no exact field match was found.
- REQ-003: [MOCK] best-effort keyword match for concept: [aggregation] revenue by reporting period -> Books_Accounts.Books_Accounts (`POTENTIAL MATCH`; UNVERIFIED) - Candidate table Books_Accounts selected but no exact field match was found.
- REQ-004: [MOCK] best-effort keyword match for concept: [field] property_id -> Books_Bills.property_id (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in Books_Bills: property_id.
- REQ-004: [MOCK] best-effort keyword match for concept: [field] reporting period -> Books_Accounts.Books_Accounts (`POTENTIAL MATCH`; UNVERIFIED) - Candidate table Books_Accounts selected but no exact field match was found.
- REQ-004: [MOCK] best-effort keyword match for concept: [field] account_name -> Books_Accounts.account_name (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in Books_Accounts: account_name.
- REQ-004: [MOCK] best-effort keyword match for concept: [aggregation] amount -> Books_Cash_Transactions.amount (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in Books_Cash_Transactions: amount.
- REQ-004: [MOCK] best-effort keyword match for concept: [field] asset_category -> Property_Current_Assets.asset_category (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in Property_Current_Assets: asset_category.
- REQ-004: [MOCK] best-effort keyword match for concept: [field] asset_date -> Property_Current_Assets.asset_date (`DIRECT MATCH`; SCHEMA_SUPPORTED) - Matched metadata fields in Property_Current_Assets: asset_date.
- REQ-005: [MOCK] best-effort keyword match for concept: [entity] Build and demonstrate a feasibility sample, then produce a statement of work containing the finalized scope, timeline, and cost estimates. -> Books_Accounts.Books_Accounts (`POTENTIAL MATCH`; UNVERIFIED) - Candidate table Books_Accounts selected but no exact field match was found.

## Gap Register
- No gaps returned.

## Clarification Questions
- None identified.
